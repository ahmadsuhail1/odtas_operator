from .device import getDeviceList 
